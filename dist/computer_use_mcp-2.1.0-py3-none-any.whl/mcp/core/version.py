"""Version information for computer-use-mcp package"""


__version__ = "1.0.0"
__version_info__ = (1, 0, 0)
__author__ = "Sundeep G"
__author_email__ = "sundeepg8@gmail.com"
__license__ = "MIT"
__copyright__ = "Copyright 2025 Sundeep G""""Version information for computer-use-mcp package"""

__version__ = "1.0.0"
__version_info__ = (1, 0, 0)
__author__ = "Sundeep G"
__author_email__ = "sundeepg8@gmail.com"
__license__ = "MIT"
__copyright__ = "Copyright 2025 Sundeep G"